##################################################################################### 
## Project name : Agentic AI POC                                                    #
## Business owner , Team : Data and AIA                                             #
## Notebook Author , Team: POC Team                                                 #
## Date: 17th Nov 2025                                                              #
## Puprose of Notebook:                                                             #
##  HTTP-triggered Azure Function that:                                             #
##      1. Recieves and issue description from a diag aagent [Service Desk/App].    #
##      2. Uses Azure AI Foundry troubleshoot agent to resolve the issue to an      #
##         Azure Automation Runbook.                                                #
##      3. Clones the runbook with additional metadata [eg. target machine] and     #
##         publish it for execution.                                                #
## Code 
#####################################################################################

# # Load all the libraries
import json
import logging
import os
import uuid
from datetime import datetime
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple

import azure.functions as func
from azure.eventhub import EventHubProducerClient, EventData
from pydantic import BaseModel, ValidationError

# Auth / SDKs
from azure.identity import DefaultAzureCredential
from azure.mgmt.automation import AutomationClient


# Optional: Azure AI Projects
from azure.ai.projects import AIProjectClient
from azure.ai.agents.models import ListSortOrder
import requests

# Access the storage account
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
from azure.core.exceptions import ResourceExistsError, ResourceNotFoundError

from dotenv import load_dotenv
load_dotenv()


# Akeyless [Fetch Secrets]
import akeyless
from akeyless_cloud_id import CloudId


#=============================Logging Setup========================================================
# Azure function configures root logger but we are ensuring the level.
logging.getLogger().setLevel(logging.INFO)

#=============================Data Class Module==========================================================
@dataclass
class AutomationConfig:
    """Configuration required for Azure Automation interactions."""
    subscription_id:str
    resource_group: str
    automation_account: str
    location: str

@dataclass
class FoundryConfig:
    """Configuration required for Azure AI Foundry interactions."""
    endpoint:str
    diagnostic_agent_id: str
    troubleshoot_agent_id: str
    deployment: str
    api_version: str

@dataclass
class AppConfig:
    """Configuration object for the function."""
    environment:str
    automation: AutomationConfig
    foundry: FoundryConfig

#=========================================Helpers: Setting Akeyless===========================================
def read_akeyless_dicts():
    """ FETCH ID AND SECRET FROM AKEYLESS DICTIONARY
        - AGENT VARIABLES
        - AUTOMATION VARIABLES
        All the secrets are stored in akeyless
    """
    logging.info("Reading Condiguration dictionaries from Akeyless.")
    
    Automation_Variable= {
        "AZ_SUBSCRIPTION_ID": "4c85c528-9da9-48ac-a5c3-41bd351728eb",
        "AZ_RESOURCE_GROUP": "rg-fbntf-ais-swce-poc",
        "AZ_AUTOMATION_ACCOUNT": "aa-mbfin-ais-swce-poc",
        "LOCATION":"Sweden Central"
        }
    Foundry_Variable={
        "Endpoint": "https://aifoundry-rjteh-ais-swce-poc.services.ai.azure.com/api/projects/aifp-uqqnf-ais-swce-poc",
        "Model_Name": "gpt-5-mini",
        "Deployment": "ITOA-Service_Desk-Agentic_AI_POC-gpt-5-mini",
        "API_Version": "2024-12-01-preview",
        "DIAGNOSTIC_Agent_ID": "asst_MxWLoHuCHSwnPxyZfzUe2EOb",
        "TROUBLESHOOT_Agent_ID": "asst_fP3eyPFbOQGjFvH7m909Kdi6"}
    logging.info("Akeyless dictionaries loaded successfully.")
    return Foundry_Variable, Automation_Variable

#=========================================Helpers: Loading Configuration===========================================
def load_config_from_akeyless() ->Tuple[AppConfig, Dict[str, Any], Dict[str, Any]]:
    """
    Build AppConfig from Akeyless dictionaries and environment.
    """
    app_env= "dev"
    foundry_dict, automation_dict= read_akeyless_dicts()
    automation_cfg =AutomationConfig(
        subscription_id= automation_dict['AZ_SUBSCRIPTION_ID'],
        resource_group = automation_dict['AZ_RESOURCE_GROUP'],
        automation_account = automation_dict['AZ_AUTOMATION_ACCOUNT'],
        location = automation_dict['LOCATION']
        )
    foundry_cfg = FoundryConfig(
        endpoint= foundry_dict['Endpoint'],
        diagnostic_agent_id= foundry_dict['DIAGNOSTIC_Agent_ID'],
        troubleshoot_agent_id= foundry_dict['TROUBLESHOOT_Agent_ID'],
        deployment= foundry_dict['Deployment'],
        api_version= foundry_dict['API_Version']
        )
    config = AppConfig(environment= app_env, automation = automation_cfg, foundry = foundry_cfg)
    return config, foundry_dict, automation_dict

#==============================================Utilities========================================================

def json_response(payload: Dict[str, Any], status: int =200) ->func.HttpResponse:
    """Returns a JSON-formatted HTTP response within consistent headers."""
    return func.HttpResponse(
        body = json.dumps(payload),
        status_code= status,
        mimetype ="application/json",
        )

def validate_request_body(body: Dict[str, Any]) -> Tuple [str, bool, str]:
    """
    Validate and parse incoming HTTP JSON payload.
    Expected Schema:
    {
        "diagnostic_output" : "string, required",
        "execute": true/false, optional, default= true,
        "target_machine" : "string, required",
        "session_id" : "session_id"  
    }
    """
    diagnostic_output = body.get("diagnostic_output")
    if not isinstance(diagnostic_output, str) or not diagnostic_output.strip():
        raise ValueError("Field 'diagnostic_output' is required and must be a non-empty string.")
    
    execute = bool(body.get("execute", True))
    target_machine = body.get("target_machine", "").strip() or "UNSPECIFIED"
    session_id = body.get("session_id")
    loggedin_username=body.get("loggedin_username")
    if not isinstance(target_machine, str):
        raise ValueError("Field 'target_machine' is required and must be a non-empty string.")
    if not isinstance(session_id, str):
        raise ValueError("Field 'session id' is required and must be a non-empty string.")
    if not isinstance(loggedin_username, str):
        raise ValueError("Field 'loggedin_username' is required and must be a non-empty string.")

    return diagnostic_output.strip(), execute, target_machine, session_id, loggedin_username

def get_default_credential() ->DefaultAzureCredential:
    """ Create a Default Azure Credentialinstance suitable for functionapps."""
    return DefaultAzureCredential(
        exclude_interactive_browser_credential=True,
        exclude_visual_studio_code_credential=True,
        exclude_shared_token_cache_credential=True,
        exclude_powershell_credential=True)


#============================================Event Hub Logging==========================================
class EventHubLogger:
    """
    Simple wrapper for sending JSON events to Azure Event Hub using AAD
    authentication. No connection string is user.
    """
    def __init__(self, automation_dict: Dict[str, Any], credential: DefaultAzureCredential):
        namespace =""
        name=""

        if not namespace or not name:
            logging.warning(
                "Event Hub namespace/name not configured. Event will not be sent."
                )
            self.producer: Optional[EventHubProducerClient] = None
            return
        
        try:
            self.producer= EventHubProducerClient(
                fully_qualified_namespace = namespace,
                eventhub_name = name,
                credential= credential
            )
            logging.info("Event Hub Logger initialised for hub '%s'.", name)
        except Exception:
            logging.exception("Failed to initialise Eventhub producer client.")
            self.producer=None
    
    def send_event(self, event: Dict[str, Any]) -> None:
        """
        Send a single JSON event to Event Hub. Failure is looged but doesn't
        break the main flow.
        """
        if not self.producer:
            return
        
        try:
            paylod = json.dumps(event)
            event_data =EventData(payload)
            with self.producer:
                batch = self.producer.create_batch()
                batch.add(event_data)
                self.producer.send_batch(batch)
            logging.info("Event sent to Event Hub: %s", event.get("event_type"))
        except Exception:
            logging.exception("Failed to send event to eventhub.")

#==============================================AZURE AUTOMATION===================================
class AzureautomationService:
    """Wrapper around azure automation operations (Runbook CRUD, REST content)."""

    def __init__(self, config: AutomationConfig, credential: DefaultAzureCredential):
        self.config=config
        self.credential=credential
        self.client = AutomationClient(credential, config.subscription_id)

    def get_rest_token(self) -> str:
        """Acquire a token for Azure Resource Manager using managed identity."""
        token = self.credential.get_token("https://management.azure.com/.default").token
        return token

    def fetch_runbook_content(self, runbook_name: str) -> Optional[str]:
        """
        Fetch runbook content directly from Azure via REST API.
        Returns the runbook powershell script as string or None if not found.
        """
        token=self.get_rest_token()
        url = (
            f"https://management.azure.com/subscriptions/{self.config.subscription_id}"
            f"/resourceGroups/{self.config.resource_group}"
            f"/providers/Microsoft.Automation/automationAccounts/{self.config.automation_account}"
            f"/runbooks/{runbook_name}/content?api-version=2024-10-23"
            )
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/octet-stream"
            }
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            logging.info("Fetched content for runbook '%s'.", runbook_name)
            return response.content.decode("utf-8", errors="ignore")
        logging.warning(
            "Failed to fetch content for runbook '%s'. status: %s, Bodr: %s",
            runbook_name,
            response.status_code,
            response.text,
            )
        return None

    def create_or_update_runbook(self, runbook_name: str, runbook_content: str) -> None:
        """
        Creates Runbook [Powershell] and uploads the content, then publishes it.
        STEPS:
            1. Ensure that meta data exists [create_or_update].
            2. Upload the draft content.
            3. Publishes the Runbook.
            4. Run the Runbook
        """
        logging.info("Creating or updating runbook '%s'.", runbook_name)

        # 1. Create or Update Meta Data
        runbook = self.client.runbook.create_or_update(
            resource_group_name = self.config.resource_group,
            automation_account_name= self.config.automation_account,
            runbook_name = runbook_name,
            parameters={
                "location": self.config.location,
                "properties" : {
                    "runbookType": "PowerShell",
                    "logProgress": False,
                    "logVerbose": False,
                }
            }
        )
        logging.info(
            "Runbook metadata ensured for '%s'.Resource ID: %s",
            runbook_name,
            runbook.id
            )
      
        # 2. Upload Content to Draft Runbook
        draft_poller = self.client.runbook_draft.begin_replace_content(
            resource_group_name= self.config.resource_group,
            automation_account_name=self.config.automation_account,
            runbook_name = runbook_name,
            runbook_content = runbook_content
        )

        draft_poller.result()
        logging.info("Runbook draft content uploaded for'%s'", runbook_name)

        # 3. Publish the script into automation account
        publish_poller=self.client.runbook.begin_publish(
            resource_group_name=self.config.resource_group,
            automation_account_name=self.config.automation_account,
            runbook_name = runbook_name,
        )
        publish_poller.result()
        logging.info("Runbook '%s' published successfully.", runbook_name)

        # 4. Execute the script in user machine via SCCM
        logging.info("Starting runbook execution on Hybrid Worker Group: %s", runbook_name)
        job_name = f"job_{runbook_name}"
        job = self.client.job.create(
            resource_group_name=self.config.resource_group,
            automation_account_name=self.config.automation_account,
            job_name=job_name,
            parameters={
                "properties": {
                    "runbook": {"name": runbook_name},
                    "parameters": {},  # no params passed
                    "runOn": "Agentic_AI_POC_SCCM"   # <-- 🔥 IMPORTANT
                }
            }
        )

        logging.info(
            "Runbook execution started on Hybrid Worker Group. Job ID = %s",
            job.id
        )

        return job_name, job.job_id
    

#============================================USER COMPARISON============================================
    def test_user_comparison(self,tevacorp_user_id):
        tevacorp_testcorp_comparison_dictionary = {
            "PRA01":"TestPrashanth",
            "ARR02": "TestArchudan",
            "NRODRIGUES": "TestNatasha",
            "RSRINIVASA02": "TestRakesh",
            "NHADIMANI": "TestNidhi",
            "MMENJIVA": "TestMaynor",
            "MAADAMS": "TestMalcolm",
            "BWARNER": "TestBrian",
            "SROWDEN": "TestSteven",
            "AATAK": "TestAleyna",
            "MYENI": "TestMert",
            "ASHEINFELD": "TestAviram",
            "EGILBOA01": "TestEli",
            "CSALGADO02": "TestCassandra",
            "BAGUILAR": "TestBetsabe",
            "HSHAH11": "TestHarsh",
            "KER01":"GLSDUser1",
            "VPRAKASH07":"GLSDUser1",
            "KDAS":"GLSDUser1",
            "VJADHAV08":"GLSDUser1",
            "LSOJIC":"GLSDUser1",
            "KSNAI":"GLSDUser1",             
        }
        if tevacorp_user_id.upper() in tevacorp_testcorp_comparison_dictionary.keys():
            return tevacorp_testcorp_comparison_dictionary[tevacorp_user_id.upper()]
        else:
            return tevacorp_user_id.upper()

    # ###############  FUNCTION: get_output_by_runbook_name ###############
    def get_runbook_output(self,job_name: str, job_id: str) -> str:
        """
        Fetch Azure Automation runbook output using JOB ID.
        Works for all regions including Sweden Central.
        """

        while True:
            job_status = self.client.job.get(
                resource_group_name=self.config.resource_group,
                automation_account_name=self.config.automation_account,
                job_name=job_name
            ).status

            if job_status.lower() in ["completed", "failed","stopped"]:
                break
            time.sleep(5)
        token=self.get_rest_token()
        output_url = (
            f"https://management.azure.com/subscriptions/{self.config.subscription_id}"
            f"/resourceGroups/{self.config.resource_group}"
            f"/providers/Microsoft.Automation/automationAccounts/{self.config.automation_account}"
            f"/jobs/{job_id}/output?api-version=2023-11-01"
        )
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/octet-stream"
            }
        response = requests.get(output_url, headers=headers)
        if response.status_code == 200:
            logging.info("Fetched output for the job '%s'.", job_id)
            return response.text

        logging.warning(
            "Failed to fetch the output '%s'. status: %s, Bodr: %s",
            job_id,
            response.status_code,
            response.text,
            )
        return None

    def clone_runbook_with_metadata(self, source_runbook_name: str, system_name: str, issue_text: str, environment: str, session_id: str, loggedin_username: str) -> str:
        """
        Creates a new runbook by cloning an existing runbook's content and
        adding contextual metadata as a header comment.
        Returns:
            Name of the newly created runbook.
        """
        original_content=  self.fetch_runbook_content(source_runbook_name)
        if original_content is None:
            raise ValueError(f"No content returned for runbook '{source_runbook_name}'")
        timestamp= datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        source_script = f"$SystemName:{system_name}\n"
        new_runbook_name = f"{source_runbook_name}_{system_name}_{session_id}"

        header_block = [
            f"# Generated by Agentic Automation Team- ",
            f"$ScriptName = '{new_runbook_name}'",
            f"$DeviceName = '{system_name}' ",
            f'$Loggedin_Username = "{self.test_user_comparison(loggedin_username)}" ',
            f"Import-Module ($Env:SMS_ADMIN_UI_PATH.Substring(0,$Env:SMS_ADMIN_UI_PATH.Length-5) + '\ConfigurationManager.psd1')",
            f"cd CBL:",
            f"# Step 1: Inline script content",
            f"$scriptText = @'",
            f'$Loggedin_Username = "{self.test_user_comparison(loggedin_username)}" ',
            ]
        annotated_content = "\n".join(header_block) + original_content

        job_name, job_id=self.create_or_update_runbook(new_runbook_name, annotated_content)
        return new_runbook_name,job_name,job_id

#=============================================Azure AI Foundry==========================================

    
def resolve_runbook_from_issue(diagnostic_output: str) ->Optional[str]:
    """
    Sends the diagnostic_output to the troubleshoot agent and expects a final message
    that contains the resolved runbook name.
    Returns:
        Resolved runbook name or None if no mapping was found.
    """
    runbook_name="Troubleshoot" + str(diagnostic_output[8:])
    return runbook_name

#==============================================Azure Function Entry======================================

def main(req: func.HttpRequest) -> func.HttpResponse:
    """
    HTTP-triggered Azure Function entry point.
    Responsibilities:
    - Validate and parse request body.
    - Load configuration (environment, automation, foundry).
    - Resolve runbook name via Foundry agent.
    - Optionally clone and publish an new runbook.
    - Return a structured JSON response with detailed status.
    """
    correlation_id = req.headers.get("x-correlation-id", str(uuid.uuid4()))
    logging.info("Request recieved for Agentic Automationfunction. CORRELATIONID = %s", correlation_id)
    time_logger={}
    try:
        # 1. Parse JSON body
        try:
            time_logger['JSON_Parser_Start']=datetime.utcnow().isoformat() +'Z'
            request_body = req.get_json()
            time_logger['JSON_Parser_End']=datetime.utcnow().isoformat() +'Z'
        except ValueError:
            logging.warning("Invalid JSON in request body.")
            return json_response(
                {"Success": False, "error": {"message":"Invalid JSOn payload."}},
                status = 400
            )
        
        # 2. Validate Schema
        try:
            time_logger['Schema_Validation_Start']=datetime.utcnow().isoformat() +'Z'
            diagnostic_output, execute, target_machine, session_id, loggedin_username = validate_request_body(request_body)
            time_logger['Schema_Validation_End']=datetime.utcnow().isoformat() +'Z'
        except ValueError as value_error:
            logging.warning("Request validation failed: %s", value_error)
            return json_response(
                {"Success": False, "error":{"message": str(value_error)}},
                status= 400
            )

        #3. Load configuration [Env, Automation, Foundry]
        try:
            time_logger['Config_Start']=datetime.utcnow().isoformat() +'Z'
            config, foundry_dict, automation_dict = load_config_from_akeyless()
            time_logger['Config_End']=datetime.utcnow().isoformat() +'Z'
        except EnvironmentError as environment_error:
            logging.exception("Configuration loading failed.")
            return json_response(
                {"Success":False, 
                "error":{
                    "message":f"Configuration error.",
                    "details": str(environment_error)
                    }
                },
                status = 500
            )
        credential = get_default_credential()
        automation_service = AzureautomationService(config.automation, credential)
        event_logger= EventHubLogger(automation_dict, credential)

        # 1. Log "Issue Recieved"
        event_logger.send_event(
            {
                "event_type": "diagnostic_output recieved",
                "correlation_id": correlation_id,
                "environment": config.environment,
                "target_machine": target_machine,
                "execute": execute,
                "timestamp_utc": datetime.utcnow().isoformat() +'Z',
            }
        )
        #4. Resolve runbook using AI Foundry Agent
        runbook_name  = resolve_runbook_from_issue(diagnostic_output)
        if not runbook_name:
            event_logger.send_event(
                {
                    "event_type": "Runbook Resolution Failed",
                    "correlation_id": correlation_id,
                    "environment": config.environment,
                    "timestamp_utc": datetime.utcnow().isoformat() +'Z',
                }
            )
            return json_response(
                {"Success": False, "error": {"message":(
                    "No Runbook could be resolved for the given diagnostic_output.",
                    "Please contact the agentic AI POC team."
                    )}},
                    status =404
            )

        #5. Execute path: Clone runbook with metadata, publish and Run
        try:
            cloned_name, job_name, job_id = automation_service.clone_runbook_with_metadata(
                source_runbook_name= runbook_name,
                system_name = target_machine,
                issue_text = diagnostic_output,
                environment = config.environment,
                session_id = session_id,
                loggedin_username=loggedin_username,
                
            )
        except Exception as unknown_exception:
            logging.exception("Runbook cloning failed.")
            event_logger.send_event(
                {
                    "event_type": "Runbook Clone Failed",
                    "correlation_id": correlation_id,
                    "environment": config.environment,
                    "Original Runbook": runbook_name,
                    "error": str(unknown_exception),
                    "timestamp_utc": datetime.utcnow().isoformat() +'Z',
                }
            )
            return json_response(
                {"Success": False,
                "error":{
                    "message":"Runbook cloning or publishing failed.",
                    "details": str(unknown_exception)
                    }
                },
                status = 502
            )

        logging.info("Runbook cloned successfully: %s", cloned_name)
        event_logger.send_event(
            {
                "event_type": "Runbook cloned successfully",
                "correlation_id": correlation_id,
                "environment": config.environment,
                "Original Runbook": runbook_name,
                "Cloned_Runbook": cloned_name,
                "target_machine": target_machine,
                "timestamp_utc": datetime.utcnow().isoformat() +'Z',
            }
        )

        
        return json_response(
            {
                "Success": True,
                "original_runbook_name": runbook_name,
                "cloned_runbook_name": cloned_name,
                "job_name":job_name,
                "job_id": job_id,
                "executed": True,
                "target_machine": target_machine,
                "environment": config.environment,
                "message": (
                    f"Issue resolution process have been triggered and it may take few minutes."
                    ),
            },
            status = 200
        )

    
    except Exception as unhandled_exception:
        #Final safeguard: log and return generic error
        logging.exception("Unhandled exception in agentic automation function.")
        return json_response(
            {
                "Success": False,
                "error":{
                    "message": "Unhandled Server error. Please contact the automation team.",
                    "details": str(unhandled_exception),
                }
            },
            status= 500
        )

